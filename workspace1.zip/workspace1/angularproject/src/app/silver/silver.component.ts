import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-silver',
  templateUrl: './silver.component.html',
  styleUrls: ['./silver.component.css']
})
export class SilverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
