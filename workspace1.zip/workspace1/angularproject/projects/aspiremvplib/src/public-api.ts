/*
 * Public API Surface of aspiremvplib
 */

export * from './lib/aspiremvplib.service';
export * from './lib/aspiremvplib.component';
export * from './lib/aspiremvplib.module';
export  * from './lib/auth/auth.component'
