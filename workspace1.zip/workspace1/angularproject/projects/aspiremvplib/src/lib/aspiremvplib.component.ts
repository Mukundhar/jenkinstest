import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-aspiremvplib',
  template: `
    <p>
      aspiremvplib works!
    </p>
  `,
  styles: []
})
export class AspiremvplibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
